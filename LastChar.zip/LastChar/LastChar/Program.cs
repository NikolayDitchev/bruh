﻿using System;

namespace LastChar
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            Console.WriteLine(input[input.Length - 1] + input + input[input.Length - 1]);
        }
    }
}
