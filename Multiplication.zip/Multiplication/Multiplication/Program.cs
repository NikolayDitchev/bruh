﻿using System;

namespace Multiplication
{
    class Program
    {
        static void Main(string[] args)
        {
            string x, y, z;
            x = Console.ReadLine();
            y = Console.ReadLine();
            z = Console.ReadLine();

            int xx, yy, zz;
            xx = Int32.Parse(x);
            yy = Int32.Parse(y);
            zz = Int32.Parse(z);

            int result = xx * yy * zz;
            Console.WriteLine(result);
        }
    }
}
