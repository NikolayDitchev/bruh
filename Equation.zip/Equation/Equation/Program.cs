﻿using System;

namespace Equation
{
    class Program
    {
        static void Main(string[] args)
        {
            string a, b, c;
            a = Console.ReadLine();
            b = Console.ReadLine();
            c = Console.ReadLine();
          

            int aa, bb, cc;
            aa = Int32.Parse(a);
            bb = Int32.Parse(b);
            cc = Int32.Parse(c);

            int result = (aa + bb) * cc;
            Console.WriteLine(result);
            result = (aa * bb) + (bb * cc);
            Console.WriteLine(result);
            



        }
    }
}
