﻿using System;

namespace swapNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string x, y;
            x = Console.ReadLine();
            y = Console.ReadLine();
            string temp = x;
            x = y;
            y = temp;
            Console.WriteLine(x);
            Console.WriteLine(y);
        }
    }
}
