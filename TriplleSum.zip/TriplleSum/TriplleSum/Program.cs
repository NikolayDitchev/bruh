﻿using System;

namespace TriplleSum
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());

            if(x == y)
            {
                Console.WriteLine(3 * (x + y));
            }
            else
            {
                Console.WriteLine(x + y);
            }
        }
    }
}
