﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3CharSubstring
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string subtr = "";
            for(int i = 0; i < 3 && i < input.Length; i++)
            {
                subtr += input[i];
            }
            Console.WriteLine(subtr + input + subtr);
        }
    }
}
