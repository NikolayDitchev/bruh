﻿using System;

namespace RemoveChar
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int index = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(input.Remove(index, 1));
        }
    }
}
