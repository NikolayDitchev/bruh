﻿using System;

namespace _30
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());

            if((x == 30) || (y ==30) || (x + y == 30))
            {
                Console.WriteLine("True");

            }
            else
            {
                Console.WriteLine("false");
            }
        }
    }
}
