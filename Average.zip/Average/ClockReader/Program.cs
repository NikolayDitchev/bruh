﻿using System;

namespace ClockReader
{
    class Program
    {
        static void Main(string[] args)
        {
            string a, b, c, d;
            a = Console.ReadLine();
            b = Console.ReadLine();
            c = Console.ReadLine();
            d = Console.ReadLine();

            int aa, bb, cc, dd;
            aa = Int32.Parse(a);
            bb = Int32.Parse(b);
            cc = Int32.Parse(b);
            dd = Int32.Parse(d);


            int result = (aa + bb + cc + dd) / 4;
            Console.WriteLine(result);
        }
    }
}
