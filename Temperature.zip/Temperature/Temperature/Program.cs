﻿using System;

namespace Temperature
{
    class Program
    {
        static void Main(string[] args)
        {
            int cels = Convert.ToInt32(Console.ReadLine());
            int fahr = (cels * 9 / 5) + 32;
            int kelv = cels + 273;
            Console.WriteLine(kelv);
            Console.WriteLine(fahr);
        }
    }
}
