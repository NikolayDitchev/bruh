﻿using System;

namespace Operations
{
    class Program
    {
        static void Main(string[] args)
        {
            string x, y; 
            x = Console.ReadLine();
            y = Console.ReadLine();

            int xx, yy;
            xx = Int32.Parse(x);
            yy = Int32.Parse(y);

            Console.WriteLine(xx + " + " + yy + " = " + (xx + yy));
            Console.WriteLine(xx + " * " + yy + " = " + xx * yy);
            Console.WriteLine(xx + " - " + yy + " = " + (xx - yy));
            Console.WriteLine(xx + " / " + yy + " = " + xx / yy);
            Console.WriteLine(xx + " mod " + yy + " = " + xx % yy);
        }
    }
}
